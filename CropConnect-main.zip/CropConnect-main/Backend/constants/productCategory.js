const category = [
  "rice",
  "wheat",
  "nuts",
  "sugar",
  "spices",
  "fruits",
  "vegetables",
  "pulses",
];

module.exports = category;
