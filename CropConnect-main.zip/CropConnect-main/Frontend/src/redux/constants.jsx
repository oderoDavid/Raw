export const ADD_SELLER_DATA = "seller_info";
export const ADD_USER_DATA = "user_info";
export const ADD_PRODUCT_DATA = "product_info";
export const ADD_TO_CART = "add_to_cart";
export const REMOVE_FROM_CART = "remove_from_cart";
export const INC_QTY_IN_CART = "increase_qty";
export const DEC_QTY_IN_CART = "decrease_qty";
export const EDIT_PRODUCT = "edit_product";
